# RELEASE HISTORY

## 1.0.0 / 2012-12-24

This initial release of the test gem contains the basics
of any Ruby project plus some a few additional files.

Changes:

* Initial release.

