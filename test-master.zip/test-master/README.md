# Test

This Ruby gem is a **testbed** strictly for the purposes of testing any other
projects that can make use of it.

Presently this project consists of the basic parts of a typical Ruby project, 
such as a no-op `lib/test.rb` file and this `README.md` file, plus a couple of
other files for testing things like the [RC](http://rubyworks.github.com) gem.

If there is something you'd like this project to contain for your testing purposes
then please feel free to request it. As long as it does not improperly interfere with
any other need it will be accepted.

